# 🚀 Deploy Your Portfolio to GitHub Pages

This guide will walk you through deploying your robotics portfolio to GitHub Pages step by step.

## 📋 Prerequisites

- A GitHub account
- Git installed on your computer
- Your portfolio files (already prepared!)

---

## 🎯 Step-by-Step Deployment Guide

### Step 1: Create a GitHub Repository

1. Go to [GitHub](https://github.com) and log in
2. Click the **"+"** icon in the top right corner
3. Select **"New repository"**
4. Repository settings:
   - **Repository name**: Choose a name (e.g., `robotics-portfolio`, `my-portfolio`)
   - **Description**: "My Professional Robotics Engineering Portfolio"
   - **Visibility**: Choose **Public** (required for free GitHub Pages)
   - **DO NOT** initialize with README, .gitignore, or license (we already have files)
5. Click **"Create repository"**

**📝 Note down your repository details:**
- GitHub Username: `YOUR_GITHUB_USERNAME`
- Repository Name: `YOUR_REPO_NAME`

---

### Step 2: Update Your Portfolio Configuration

Before deploying, you need to update the `homepage` field in `package.json` with your actual GitHub details.

1. Open the file: `/app/frontend/package.json`

2. Find this line (around line 5):
   ```json
   "homepage": "https://YOUR_GITHUB_USERNAME.github.io/YOUR_REPO_NAME",
   ```

3. Replace with your actual details:
   ```json
   "homepage": "https://yourusername.github.io/robotics-portfolio",
   ```
   
   **Example:** If your GitHub username is `john-doe` and repo name is `portfolio`:
   ```json
   "homepage": "https://john-doe.github.io/portfolio",
   ```

---

### Step 3: Prepare Your Files for Deployment

Run these commands in the `/app` directory:

```bash
cd /app

# Initialize git repository
git init

# Add all files
git add .

# Create first commit
git commit -m "Initial commit: Robotics portfolio website"

# Add your GitHub repository as remote
# Replace with your actual GitHub repo URL
git remote add origin https://github.com/YOUR_GITHUB_USERNAME/YOUR_REPO_NAME.git

# Rename branch to main (if needed)
git branch -M main
```

---

### Step 4: Push Your Code to GitHub

```bash
# Push your code to GitHub
git push -u origin main
```

**If prompted for credentials:**
- Username: Your GitHub username
- Password: Use a [Personal Access Token](https://github.com/settings/tokens) (not your GitHub password)

---

### Step 5: Deploy to GitHub Pages

Now deploy your portfolio using the automated script:

```bash
cd /app/frontend

# Deploy to GitHub Pages
yarn deploy
```

This command will:
1. Build your portfolio (production-optimized)
2. Create a `gh-pages` branch
3. Push the built files to GitHub

**⏱️ This process takes 1-2 minutes.**

---

### Step 6: Enable GitHub Pages

1. Go to your repository on GitHub
2. Click **"Settings"** (top menu)
3. Scroll down to **"Pages"** in the left sidebar
4. Under **"Source"**:
   - Branch: Select **`gh-pages`**
   - Folder: Select **`/ (root)`**
5. Click **"Save"**

**🎉 Your site will be published at:**
```
https://YOUR_GITHUB_USERNAME.github.io/YOUR_REPO_NAME
```

**⏱️ Initial deployment takes 2-5 minutes to go live.**

---

## 🔄 Making Updates

After making changes to your portfolio:

```bash
# Navigate to frontend directory
cd /app/frontend

# Deploy updates
yarn deploy
```

Changes will be live in 1-2 minutes.

---

## 📝 Customizing Your Portfolio

### Edit Your Information

1. **Personal Information:**
   - File: `/app/frontend/src/data/portfolioData.js`
   - Update: name, title, email, phone, location, bio, social links

2. **Projects:**
   - Add/edit project entries in the `projects` array
   - Update images, descriptions, and technologies

3. **Experience:**
   - Modify the `experience` array with your work history

4. **Publications:**
   - Update the `publications` array with your research papers

5. **Skills:**
   - Adjust skill levels and add new skills

### After Editing

```bash
cd /app/frontend
yarn deploy
```

---

## 🎨 Advanced Customization

### Colors

Edit `/app/frontend/src/index.css` to change the color scheme:
```css
--primary: /* Your primary color */
```

### Components

All components are in `/app/frontend/src/components/`
- `Header.jsx` - Navigation
- `Hero.jsx` - Hero section
- `About.jsx` - About section
- And more...

---

## ❓ Troubleshooting

### Issue: 404 Error After Deployment

**Solution:** Make sure the `homepage` field in `package.json` matches your GitHub Pages URL exactly.

### Issue: Images Not Loading

**Solution:** Check that image URLs are absolute (starting with `https://`) or properly referenced from the public folder.

### Issue: Changes Not Showing

**Solutions:**
1. Clear browser cache (Ctrl+Shift+R or Cmd+Shift+R)
2. Wait 2-3 minutes for GitHub to rebuild
3. Check GitHub Actions tab for deployment status

### Issue: "Permission denied" when pushing

**Solution:** Generate a [Personal Access Token](https://github.com/settings/tokens) and use it as your password.

---

## 🌐 Custom Domain (Optional)

To use a custom domain (e.g., `www.yourname.com`):

1. Create a file: `/app/frontend/public/CNAME`
2. Add your domain:
   ```
   www.yourname.com
   ```
3. In your domain registrar settings, add these DNS records:
   ```
   Type: A, Host: @, Value: 185.199.108.153
   Type: A, Host: @, Value: 185.199.109.153
   Type: A, Host: @, Value: 185.199.110.153
   Type: A, Host: @, Value: 185.199.111.153
   Type: CNAME, Host: www, Value: YOUR_GITHUB_USERNAME.github.io
   ```
4. In GitHub Settings > Pages, enter your custom domain
5. Enable "Enforce HTTPS"

---

## 📊 Monitoring Your Site

- **GitHub Actions:** Check deployment status in the "Actions" tab
- **Analytics:** Add Google Analytics by editing `/app/frontend/public/index.html`

---

## 🎯 Quick Reference Commands

```bash
# Deploy updates
cd /app/frontend && yarn deploy

# Test locally
cd /app/frontend && yarn start

# Build production version
cd /app/frontend && yarn build
```

---

## 📚 Additional Resources

- [GitHub Pages Documentation](https://docs.github.com/en/pages)
- [React Deployment Guide](https://create-react-app.dev/docs/deployment/)
- [Custom Domain Setup](https://docs.github.com/en/pages/configuring-a-custom-domain-for-your-github-pages-site)

---

## ✅ Deployment Checklist

- [ ] Created GitHub repository
- [ ] Updated `homepage` in package.json
- [ ] Initialized git and pushed code
- [ ] Ran `yarn deploy`
- [ ] Enabled GitHub Pages in repository settings
- [ ] Waited 2-5 minutes for initial deployment
- [ ] Visited your live site!

---

**🎉 Congratulations! Your portfolio is now live on the internet!**

For any questions or issues, refer to the troubleshooting section above.

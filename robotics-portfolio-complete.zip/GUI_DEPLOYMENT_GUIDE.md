# 🎨 GitHub Pages Deployment - GUI Method (No Command Line!)

**Complete guide using GitHub Desktop - No terminal commands required!**

---

## 📋 What You'll Need

1. **GitHub Account** - [Sign up here](https://github.com/signup) (free)
2. **GitHub Desktop** - [Download here](https://desktop.github.com/) (free)
3. **Your Portfolio Files** - Download the zip file and extract it

---

## 🚀 STEP-BY-STEP DEPLOYMENT GUIDE

### **STEP 1: Download & Install GitHub Desktop**

1. Go to https://desktop.github.com/
2. Click **"Download for Windows"** or **"Download for Mac"**
3. Install the application
4. Open GitHub Desktop
5. Sign in with your GitHub account
   - Click **"Sign in to GitHub.com"**
   - Enter your GitHub username and password
   - Click **"Authorize desktop"**

✅ **You're now signed in!**

---

### **STEP 2: Download Your Portfolio Files**

1. Download the zip file:
   - **URL:** https://github-showcase-10.preview.emergentagent.com/robotics-portfolio-complete.zip
2. **Extract/Unzip** the file to a folder on your computer
   - Right-click → "Extract All" (Windows)
   - Double-click to extract (Mac)
3. **Remember the location** of this folder (e.g., `Documents/robotics-portfolio`)

---

### **STEP 3: Create GitHub Repository (Web)**

1. **Open your web browser** and go to https://github.com
2. Click the **"+"** icon (top-right corner)
3. Click **"New repository"**

**Repository Settings:**
```
Repository name: robotics-portfolio
              (or any name you like - no spaces!)

Description: My Professional Robotics Engineering Portfolio
          (optional)

Visibility: ○ Public  ← SELECT THIS (required for free GitHub Pages)

Initialize repository:
☐ Add a README file      ← LEAVE UNCHECKED
☐ Add .gitignore         ← LEAVE UNCHECKED  
☐ Choose a license       ← LEAVE UNCHECKED
```

4. Click **"Create repository"**

✅ **Repository created!**

**📝 Note down:**
- Your GitHub username: `__________________`
- Your repository name: `__________________`

---

### **STEP 4: Update Your Configuration**

Before publishing, you need to update one file with your GitHub details.

#### **Option A: Using Notepad/TextEdit**

1. **Navigate to your extracted folder:**
   ```
   robotics-portfolio-complete/frontend/
   ```

2. **Open this file:** `package.json`
   - **Windows:** Right-click → "Open with" → "Notepad"
   - **Mac:** Right-click → "Open With" → "TextEdit"

3. **Find line 5** (around the top):
   ```json
   "homepage": "https://YOUR_GITHUB_USERNAME.github.io/YOUR_REPO_NAME",
   ```

4. **Replace with YOUR details:**
   ```json
   "homepage": "https://john-doe.github.io/robotics-portfolio",
   ```
   
   **Example:**
   - If your username is `john-doe`
   - And your repo name is `robotics-portfolio`
   - Change to: `"homepage": "https://john-doe.github.io/robotics-portfolio",`

5. **Save the file** (Ctrl+S or Cmd+S)

✅ **Configuration updated!**

---

### **STEP 5: Add Project to GitHub Desktop**

1. **Open GitHub Desktop**

2. **Add Repository:**
   - Click **"File"** menu → **"Add local repository"**
   - OR click **"Add"** dropdown → **"Add existing repository"**

3. **Choose folder:**
   - Click **"Choose..."** button
   - Navigate to your extracted folder
   - Select the **main folder** (e.g., `robotics-portfolio-complete`)
   - Click **"Select Folder"** or **"Open"**

4. **You'll see a message:** "This directory does not appear to be a Git repository"
   - Click **"create a repository"** link

5. **Initialize Repository:**
   - **Name:** (already filled)
   - **Description:** My Robotics Portfolio
   - **Git Ignore:** None
   - **License:** None
   - ☐ Keep this code private (LEAVE UNCHECKED)
   - Click **"Create Repository"**

✅ **Local repository created!**

---

### **STEP 6: Make Your First Commit**

You should now see GitHub Desktop with many files listed.

1. **Bottom-left corner:**
   - **Summary (required):** `Initial commit: Robotics portfolio website`
   - **Description:** (leave empty or add details)

2. **Click the blue button:** **"Commit to main"**

✅ **All files committed!**

---

### **STEP 7: Publish to GitHub**

1. **Click the blue button at the top:** **"Publish repository"**

2. **Publish Repository dialog:**
   ```
   Name: robotics-portfolio (or your repo name)
   Description: My Professional Robotics Engineering Portfolio
   
   ☐ Keep this code private  ← LEAVE UNCHECKED (must be public!)
   ```

3. **Click:** **"Publish Repository"**

4. **Wait 10-30 seconds** for upload to complete

✅ **Code is now on GitHub!**

**Verify:** Go to https://github.com/YOUR_USERNAME/YOUR_REPO (you should see your files!)

---

### **STEP 8: Install Node.js & Yarn**

To deploy to GitHub Pages, we need to build the website. This requires Node.js and Yarn.

#### **Install Node.js:**

1. Go to https://nodejs.org/
2. Download **"LTS" version** (recommended)
3. Run the installer
4. Click **"Next"** through all steps
5. Click **"Finish"**

#### **Install Yarn:**

**Option A: Using PowerShell (Windows) - ONE command only!**
1. Right-click **"Start"** → **"Windows PowerShell (Admin)"**
2. Copy and paste this ONE command:
   ```
   npm install -g yarn
   ```
3. Press Enter
4. Wait for installation to complete

**Option B: Using Terminal (Mac) - ONE command only!**
1. Open **"Terminal"** (Cmd+Space → type "Terminal")
2. Copy and paste this ONE command:
   ```
   npm install -g yarn
   ```
3. Press Enter
4. Wait for installation to complete

✅ **Node.js & Yarn installed!**

---

### **STEP 9: Install Dependencies & Deploy**

Now we'll use **ONE command** to set up and deploy your portfolio.

#### **Windows:**

1. **Open File Explorer**
2. Navigate to: `robotics-portfolio-complete/frontend/`
3. In the address bar, **type:** `cmd` and press Enter
   - This opens Command Prompt in that folder
4. **Copy and paste** this ONE command:
   ```
   yarn install && yarn deploy
   ```
5. Press **Enter**
6. **Wait 2-3 minutes** for completion

#### **Mac:**

1. **Open Finder**
2. Navigate to: `robotics-portfolio-complete/frontend/`
3. **Right-click** the `frontend` folder → **"New Terminal at Folder"**
4. **Copy and paste** this ONE command:
   ```
   yarn install && yarn deploy
   ```
5. Press **Enter**
6. **Wait 2-3 minutes** for completion

**What happens:**
- Downloads required packages (~300MB)
- Builds your portfolio
- Creates `gh-pages` branch
- Pushes to GitHub

**You'll see:**
```
✨  Done in 45.23s.
Published
```

✅ **Deployment complete!**

---

### **STEP 10: Enable GitHub Pages (Web)**

1. **Go to your repository:**
   - https://github.com/YOUR_USERNAME/YOUR_REPO

2. **Click "Settings"** (top menu)

3. **Left sidebar:** Click **"Pages"**

4. **Under "Source":**
   - **Branch:** Select **`gh-pages`** (from dropdown)
   - **Folder:** Select **`/ (root)`**
   - Click **"Save"**

5. **Wait 30 seconds**, then **refresh the page**

6. You'll see a **green banner:**
   ```
   ✅ Your site is live at https://YOUR_USERNAME.github.io/YOUR_REPO/
   ```

7. **Click the link** or copy it to your browser

✅ **YOUR PORTFOLIO IS NOW LIVE! 🎉**

---

## 🎨 STEP 11: Customize Your Content (Optional)

### **Edit Your Information:**

1. **Open:** `frontend/src/data/portfolioData.js`
   - Use Notepad (Windows) or TextEdit (Mac)

2. **Update these sections:**
   ```javascript
   personalInfo: {
     name: "Your Name",           // ← Change this
     title: "Robotics Engineer",  // ← Change this
     email: "your@email.com",     // ← Change this
     // ... etc
   }
   ```

3. **Save the file**

### **Publish Updates:**

After making changes:

1. **Open GitHub Desktop**
2. You'll see changed files listed
3. **Bottom-left:**
   - Summary: `Updated portfolio content`
4. Click **"Commit to main"**
5. Click **"Push origin"** (top-right)
6. **Run deployment command again:**
   - Open terminal in `frontend/` folder
   - Run: `yarn deploy`
   - Wait 1-2 minutes

**Changes will be live in 2-3 minutes!**

---

## 📱 Alternative: Using GitHub Web Interface

If you can't install GitHub Desktop, you can upload files directly via web:

### **Method 2: Direct Web Upload**

1. **Create repository** on GitHub (as in Step 3)

2. **In your repository page:**
   - Click **"uploading an existing file"** link

3. **Drag and drop** your files:
   - Select ALL files from your `robotics-portfolio-complete` folder
   - Drag them into the upload area
   - Wait for upload

4. **Commit:**
   - Add message: `Initial commit`
   - Click **"Commit changes"**

5. **Continue from Step 9** (Install & Deploy)

---

## 🎯 Summary Checklist

- [ ] Downloaded GitHub Desktop & signed in
- [ ] Downloaded portfolio zip file & extracted
- [ ] Created GitHub repository (public)
- [ ] Updated `package.json` with your GitHub URL
- [ ] Added project to GitHub Desktop
- [ ] Made initial commit
- [ ] Published to GitHub
- [ ] Installed Node.js & Yarn
- [ ] Ran `yarn install && yarn deploy`
- [ ] Enabled GitHub Pages in settings
- [ ] Visited your live site!

---

## 🆘 Troubleshooting

### **Issue: GitHub Desktop won't install**
**Solution:** 
- Try downloading from: https://central.github.com/deployments/desktop/desktop/latest/win32
- Or use Method 2 (Web Upload)

### **Issue: "yarn" command not found**
**Solution:**
- Restart your computer after installing Node.js
- Or install via: `npm install -g yarn`

### **Issue: Can't find package.json**
**Solution:**
- Make sure you extracted the zip file completely
- The file is in: `frontend/package.json` (inside the frontend folder)

### **Issue: gh-pages branch not showing**
**Solution:**
- Make sure `yarn deploy` completed successfully
- Check GitHub Desktop - should show "gh-pages" branch
- Refresh your repository page on GitHub

### **Issue: 404 error on site**
**Solution:**
- Check `homepage` URL in package.json matches exactly
- Format: `https://username.github.io/repo-name`
- No capital letters, no spaces
- Wait 2-5 minutes after first deployment

---

## 🎥 Visual Guide

**Here's what each step looks like:**

### **GitHub Desktop - Initial Screen:**
```
┌─────────────────────────────────────────┐
│  File  Edit  View  Repository  Help    │
├─────────────────────────────────────────┤
│                                         │
│         No repositories found           │
│                                         │
│  [Clone Repository] [Create New]        │
│  [Add Existing Repository]              │
│                                         │
└─────────────────────────────────────────┘
```

### **After Adding Files:**
```
┌─────────────────────────────────────────┐
│  Current Repository: robotics-portfolio │
│  Current Branch: main                   │
├─────────────────────────────────────────┤
│  Changes (87)                           │
│  ☑ frontend/src/App.js                  │
│  ☑ frontend/src/components/Hero.jsx    │
│  ☑ frontend/package.json                │
│  ☑ ... (84 more files)                  │
├─────────────────────────────────────────┤
│  Summary (required)                     │
│  [Initial commit]                       │
│                                         │
│  [Commit to main]  ← Click this!        │
└─────────────────────────────────────────┘
```

---

## 📞 Need More Help?

- **GitHub Desktop Guide:** https://docs.github.com/en/desktop
- **GitHub Pages Guide:** https://docs.github.com/en/pages
- **Node.js Download:** https://nodejs.org/

---

## 🎉 Congratulations!

You've successfully deployed your portfolio using only GUI tools (and one deploy command)!

**Your site:** `https://YOUR_USERNAME.github.io/YOUR_REPO`

**Share it with the world! 🌍**

---

*This guide requires minimal command line usage (only the deploy command). Everything else is done through graphical interfaces!*

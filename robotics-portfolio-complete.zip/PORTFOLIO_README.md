# 🤖 Robotics Engineer Portfolio

A professional, modern portfolio website for showcasing robotics engineering projects, publications, and expertise.

## 🌐 Live Demo

**Current Preview:** https://github-showcase-10.preview.emergentagent.com  
**Your GitHub Pages URL:** `https://YOUR_GITHUB_USERNAME.github.io/YOUR_REPO_NAME`

## ✨ Features

- **Responsive Design** - Works perfectly on all devices
- **Modern UI** - Clean, professional, tech-oriented design
- **Project Showcase** - Grid layout with filtering capabilities
- **Publications Section** - Display your research papers and conference proceedings
- **Photo Gallery** - Showcase your robotics projects with images
- **Video & CAD Models** - Dedicated sections for demonstrations and 3D models
- **Contact Form** - Let people reach out to you easily
- **Smooth Animations** - Professional hover effects and transitions
- **Fast Loading** - Optimized for performance

## 🛠️ Tech Stack

- **Frontend:** React 19
- **UI Components:** Shadcn UI + Radix UI
- **Styling:** Tailwind CSS
- **Icons:** Lucide React
- **Build Tool:** Create React App with CRACO
- **Deployment:** GitHub Pages

## 📂 Project Structure

```
/app/
├── frontend/
│   ├── public/              # Static files
│   ├── src/
│   │   ├── components/      # React components
│   │   │   ├── Header.jsx
│   │   │   ├── Hero.jsx
│   │   │   ├── About.jsx
│   │   │   ├── Skills.jsx
│   │   │   ├── Experience.jsx
│   │   │   ├── Projects.jsx
│   │   │   ├── Publications.jsx
│   │   │   ├── Gallery.jsx
│   │   │   ├── MediaShowcase.jsx
│   │   │   ├── Contact.jsx
│   │   │   ├── Footer.jsx
│   │   │   └── ui/          # Shadcn UI components
│   │   ├── data/
│   │   │   └── portfolioData.js  # ⭐ Edit your content here
│   │   ├── App.js
│   │   ├── App.css
│   │   └── index.css
│   └── package.json
└── GITHUB_PAGES_DEPLOYMENT.md  # 📖 Deployment guide
```

## 🚀 Quick Start

### Option 1: Automated Setup (Recommended)

Run the setup script:

```bash
cd /app
./setup-github-pages.sh
```

Follow the prompts to configure your GitHub details.

### Option 2: Manual Setup

1. **Create GitHub Repository:**
   - Go to GitHub and create a new public repository
   - Do NOT initialize with README

2. **Update Configuration:**
   ```bash
   # Edit /app/frontend/package.json
   # Change line 5 from:
   "homepage": "https://YOUR_GITHUB_USERNAME.github.io/YOUR_REPO_NAME"
   # To your actual details:
   "homepage": "https://yourusername.github.io/your-repo-name"
   ```

3. **Push to GitHub:**
   ```bash
   cd /app
   git init
   git add .
   git commit -m "Initial commit: Robotics portfolio"
   git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
   git branch -M main
   git push -u origin main
   ```

4. **Deploy:**
   ```bash
   cd /app/frontend
   yarn deploy
   ```

5. **Enable GitHub Pages:**
   - Go to Repository Settings → Pages
   - Set Source to `gh-pages` branch
   - Save

6. **Visit Your Site:**
   - https://YOUR_USERNAME.github.io/YOUR_REPO
   - Wait 2-5 minutes for initial deployment

## ✏️ Customization

### Edit Your Content

All portfolio content is in `/app/frontend/src/data/portfolioData.js`

**Update these sections:**
- `personalInfo` - Your name, title, contact info, social links
- `about` - Bio and expertise areas
- `skills` - Technical skills with proficiency levels
- `experience` - Work history
- `projects` - Your robotics projects
- `publications` - Research papers and publications
- `gallery` - Project photos
- `videos` - Project demonstration videos
- `cadModels` - 3D CAD model showcases

### Change Colors

Edit `/app/frontend/src/index.css`:
```css
:root {
  --primary: /* your color */;
  --secondary: /* your color */;
}
```

### Add New Sections

1. Create component in `/app/frontend/src/components/`
2. Import in `/app/frontend/src/App.js`
3. Add to navigation in `/app/frontend/src/components/Header.jsx`

## 🔄 Updating Your Portfolio

After making changes:

```bash
cd /app/frontend
yarn deploy
```

Changes will be live in 1-2 minutes.

## 📖 Full Documentation

For detailed deployment instructions, troubleshooting, and advanced configuration:

**Read:** `/app/GITHUB_PAGES_DEPLOYMENT.md`

## 🎨 Design Features

- **Clean & Professional** - No cluttered elements
- **Tech-Oriented** - Perfect for engineering portfolios
- **Modern Color Scheme** - Blue accents with dark gray backgrounds
- **Smooth Scrolling** - Professional navigation experience
- **Hover Effects** - Engaging micro-interactions
- **Responsive** - Mobile, tablet, and desktop optimized

## 📝 Content Tips

### Projects Section
- Use high-quality images
- Write clear, concise descriptions
- List key technologies used
- Include links to demos or documentation

### Publications Section
- Include DOI links
- List all co-authors
- Mention journal/conference names
- Add publication year

### Gallery Section
- Use consistent image dimensions
- Organize with categories
- Add descriptive titles

## 🐛 Troubleshooting

**Site not loading?**
- Check GitHub Pages is enabled in settings
- Verify `homepage` field in package.json is correct
- Wait 2-5 minutes after first deployment

**Images not showing?**
- Use absolute URLs (https://)
- Check image URLs are accessible

**Changes not appearing?**
- Clear browser cache (Ctrl+Shift+R)
- Wait 2-3 minutes for GitHub rebuild
- Check GitHub Actions for deployment status

## 🌟 Features to Add (Optional)

- Blog section for technical writing
- Dark/light theme toggle
- Multi-language support
- PDF resume download
- Project search functionality
- Email contact form backend

---

**Built with ❤️ for Robotics Engineers**

Need help? Check `/app/GITHUB_PAGES_DEPLOYMENT.md` for detailed instructions.

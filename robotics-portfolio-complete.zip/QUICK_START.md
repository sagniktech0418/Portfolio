# 🎯 QUICK START GUIDE - GitHub Pages Deployment

## 📋 What You Need
- GitHub account
- Git installed
- 10 minutes of time

---

## 🚀 DEPLOYMENT IN 6 STEPS

### STEP 1: Create GitHub Repository
```
1. Go to github.com
2. Click "+" → "New repository"
3. Name: "robotics-portfolio" (or any name)
4. Visibility: Public
5. DO NOT add README
6. Click "Create repository"
```
**✏️ Note:** Your username and repo name

---

### STEP 2: Update Configuration

Open: `/app/frontend/package.json`

Find line 5:
```json
"homepage": "https://YOUR_GITHUB_USERNAME.github.io/YOUR_REPO_NAME",
```

Change to YOUR details:
```json
"homepage": "https://john-doe.github.io/robotics-portfolio",
```
(Replace john-doe with your username, robotics-portfolio with your repo name)

---

### STEP 3: Initialize & Push

```bash
cd /app

git init
git add .
git commit -m "Initial commit: Robotics portfolio"
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
git branch -M main
git push -u origin main
```

**Replace:** `YOUR_USERNAME` and `YOUR_REPO` with your actual values

**If asked for password:** Use a Personal Access Token from:
https://github.com/settings/tokens

---

### STEP 4: Deploy to GitHub Pages

```bash
cd /app/frontend
yarn deploy
```

⏱️ **Wait:** 1-2 minutes

---

### STEP 5: Enable GitHub Pages

```
1. Go to: github.com/YOUR_USERNAME/YOUR_REPO
2. Click "Settings" (top menu)
3. Click "Pages" (left sidebar)
4. Under "Source":
   - Branch: gh-pages
   - Folder: / (root)
5. Click "Save"
```

---

### STEP 6: Visit Your Live Site! 🎉

```
https://YOUR_USERNAME.github.io/YOUR_REPO
```

⏱️ **Wait:** 2-5 minutes for first deployment

---

## 🎨 CUSTOMIZE YOUR CONTENT

Edit file: `/app/frontend/src/data/portfolioData.js`

Change:
- Your name, email, phone
- Bio and description
- Projects
- Skills
- Experience
- Publications
- Social media links

After editing:
```bash
cd /app/frontend
yarn deploy
```

---

## ⚡ QUICK COMMANDS REFERENCE

| Action | Command |
|--------|---------|
| Deploy updates | `cd /app/frontend && yarn deploy` |
| Test locally | `cd /app/frontend && yarn start` |
| Build production | `cd /app/frontend && yarn build` |

---

## 🆘 HELP!

**Problem:** Site shows 404
→ **Fix:** Check `homepage` in package.json matches your GitHub URL

**Problem:** Changes not showing
→ **Fix:** Clear cache (Ctrl+Shift+R) and wait 2 minutes

**Problem:** Images broken
→ **Fix:** Make sure image URLs start with https://

**Problem:** Can't push to GitHub
→ **Fix:** Create Personal Access Token: https://github.com/settings/tokens

---

## 📖 NEED MORE HELP?

Read the detailed guide: `/app/GITHUB_PAGES_DEPLOYMENT.md`

---

**🎉 You're all set! Good luck with your portfolio!**

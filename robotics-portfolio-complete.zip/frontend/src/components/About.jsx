import React from 'react';
import { Wrench, Cog, Cpu } from 'lucide-react';
import { Card } from './ui/card';
import { about } from '../data/portfolioData';

const About = () => {
  const expertiseIcons = {
    0: Wrench,
    1: Cog,
    2: Cpu,
    3: Wrench,
    4: Cog,
    5: Cpu
  };

  return (
    <section id="about" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          {/* Section Header */}
          <div className="text-center mb-16">
            <h2 className="text-4xl sm:text-5xl font-bold text-gray-900 mb-4">
              About Me
            </h2>
            <div className="w-20 h-1 bg-blue-600 mx-auto" />
          </div>

          {/* Description */}
          <div className="mb-16">
            {about.description.map((paragraph, index) => (
              <p key={index} className="text-lg text-gray-700 mb-4 leading-relaxed">
                {paragraph}
              </p>
            ))}
          </div>

          {/* Expertise Grid */}
          <div>
            <h3 className="text-2xl font-bold text-gray-900 mb-8 text-center">
              Areas of Expertise
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {about.expertise.map((item, index) => {
                const Icon = expertiseIcons[index];
                return (
                  <Card
                    key={index}
                    className="p-6 bg-white border-gray-200 hover:border-blue-500 hover:shadow-lg transition-all duration-300 group"
                  >
                    <div className="flex items-start space-x-4">
                      <div className="flex-shrink-0">
                        <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center group-hover:bg-blue-600 transition-colors">
                          <Icon className="text-blue-600 group-hover:text-white transition-colors" size={24} />
                        </div>
                      </div>
                      <div className="flex-1">
                        <h4 className="text-lg font-semibold text-gray-900 group-hover:text-blue-600 transition-colors">
                          {item}
                        </h4>
                      </div>
                    </div>
                  </Card>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
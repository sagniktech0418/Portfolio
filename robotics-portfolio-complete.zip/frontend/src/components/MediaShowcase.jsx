import React from 'react';
import { Play } from 'lucide-react';
import { Card } from './ui/card';
import { videos, cadModels } from '../data/portfolioData';

const MediaShowcase = () => {
  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          {/* Videos Section */}
          <div className="mb-20">
            <div className="text-center mb-12">
              <h2 className="text-4xl sm:text-5xl font-bold text-gray-900 mb-4">
                Project Videos
              </h2>
              <div className="w-20 h-1 bg-blue-600 mx-auto mb-4" />
              <p className="text-lg text-gray-600 max-w-2xl mx-auto">
                Watch demonstrations and testing of robotics systems in action
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {videos.map((video) => (
                <Card
                  key={video.id}
                  className="overflow-hidden bg-white border-gray-200 hover:shadow-xl transition-all duration-300 group"
                >
                  <div className="relative aspect-video bg-gray-900">
                    <img
                      src={video.thumbnail}
                      alt={video.title}
                      className="w-full h-full object-cover opacity-80 group-hover:opacity-60 transition-opacity"
                    />
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform cursor-pointer">
                        <Play className="text-white ml-1" size={28} fill="white" />
                      </div>
                    </div>
                  </div>
                  <div className="p-6">
                    <h3 className="text-xl font-bold text-gray-900 mb-2 group-hover:text-blue-600 transition-colors">
                      {video.title}
                    </h3>
                    <p className="text-gray-600 text-sm">{video.description}</p>
                  </div>
                </Card>
              ))}
            </div>
          </div>

          {/* 3D CAD Models Section */}
          <div>
            <div className="text-center mb-12">
              <h2 className="text-4xl sm:text-5xl font-bold text-gray-900 mb-4">
                3D CAD Models
              </h2>
              <div className="w-20 h-1 bg-blue-600 mx-auto mb-4" />
              <p className="text-lg text-gray-600 max-w-2xl mx-auto">
                Detailed mechanical designs and CAD assemblies
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {cadModels.map((model) => (
                <Card
                  key={model.id}
                  className="overflow-hidden bg-white border-gray-200 hover:shadow-xl hover:border-blue-500 transition-all duration-300 group cursor-pointer"
                  onClick={() => window.open(model.modelUrl, '_blank')}
                >
                  <div className="relative aspect-square bg-gray-200">
                    <img
                      src={model.thumbnail}
                      alt={model.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                    <div className="absolute top-3 right-3">
                      <span className="px-2 py-1 bg-blue-600 text-white text-xs font-medium rounded">
                        {model.software}
                      </span>
                    </div>
                  </div>
                  <div className="p-4">
                    <h3 className="text-base font-bold text-gray-900 mb-1 group-hover:text-blue-600 transition-colors">
                      {model.title}
                    </h3>
                    <p className="text-gray-600 text-sm line-clamp-2">{model.description}</p>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default MediaShowcase;
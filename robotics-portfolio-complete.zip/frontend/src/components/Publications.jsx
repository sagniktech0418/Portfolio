import React from 'react';
import { ExternalLink, BookOpen } from 'lucide-react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { publications } from '../data/portfolioData';

const Publications = () => {
  return (
    <section id="publications" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-5xl mx-auto">
          {/* Section Header */}
          <div className="text-center mb-16">
            <h2 className="text-4xl sm:text-5xl font-bold text-gray-900 mb-4">
              Publications
            </h2>
            <div className="w-20 h-1 bg-blue-600 mx-auto mb-4" />
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Research contributions to robotics and mechanical engineering
            </p>
          </div>

          {/* Publications List */}
          <div className="space-y-6">
            {publications.map((pub) => (
              <Card
                key={pub.id}
                className="p-6 bg-white border-gray-200 hover:shadow-lg hover:border-blue-500 transition-all duration-300 group"
              >
                <div className="flex items-start space-x-4">
                  {/* Icon */}
                  <div className="flex-shrink-0">
                    <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center group-hover:bg-blue-600 transition-colors">
                      <BookOpen className="text-blue-600 group-hover:text-white transition-colors" size={24} />
                    </div>
                  </div>

                  {/* Content */}
                  <div className="flex-1">
                    <h3 className="text-lg font-bold text-gray-900 mb-2 group-hover:text-blue-600 transition-colors">
                      {pub.title}
                    </h3>
                    
                    <p className="text-sm text-gray-600 mb-2">
                      {pub.authors}
                    </p>
                    
                    <div className="flex flex-wrap items-center gap-4 text-sm text-gray-500 mb-3">
                      <span className="font-medium">
                        {pub.journal || pub.conference}
                      </span>
                      <span>•</span>
                      <span>{pub.year}</span>
                      {pub.doi && (
                        <>
                          <span>•</span>
                          <span className="font-mono text-xs">{pub.doi}</span>
                        </>
                      )}
                    </div>

                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-blue-600 hover:text-blue-700 hover:bg-blue-50 -ml-2"
                      onClick={() => window.open(pub.link, '_blank')}
                    >
                      <ExternalLink size={16} className="mr-2" />
                      Read Publication
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Publications;
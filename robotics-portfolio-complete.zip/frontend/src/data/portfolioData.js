// Portfolio Template Data - Replace with your actual information

export const personalInfo = {
  name: "Your Name",
  title: "Robotics Engineer",
  subtitle: "Mechanical Design | Fabrication | System Integration",
  email: "your.email@example.com",
  phone: "+1 (555) 123-4567",
  location: "City, Country",
  bio: "Passionate Robotics Engineer with expertise in mechanical design, fabrication, assembly, and testing. Specialized in system-level integration and bringing innovative robotic solutions from concept to reality.",
  resumeLink: "#",
  social: {
    linkedin: "https://linkedin.com/in/yourprofile",
    github: "https://github.com/yourusername",
    twitter: "https://twitter.com/yourhandle",
    scholar: "https://scholar.google.com/"
  }
};

export const about = {
  description: [
    "I am a Robotics Engineer specializing in mechanical design, fabrication, and system-level integration. My work focuses on transforming innovative concepts into functional robotic systems through precise engineering and rigorous testing.",
    "With extensive experience in CAD modeling, manufacturing processes, and assembly techniques, I bring a comprehensive approach to robotics development. My expertise spans from initial design conceptualization to final product validation.",
    "I am passionate about advancing robotic technologies and creating solutions that bridge the gap between theoretical design and practical implementation."
  ],
  expertise: [
    "Mechanical Design & CAD Modeling",
    "Robot Fabrication & Assembly",
    "System-Level Integration",
    "Prototype Development & Testing",
    "Manufacturing Process Optimization",
    "Technical Documentation"
  ]
};

export const skills = {
  technical: [
    { name: "SolidWorks", level: 90 },
    { name: "CATIA", level: 85 },
    { name: "AutoCAD", level: 80 },
    { name: "Fusion 360", level: 85 },
    { name: "ANSYS", level: 75 },
    { name: "MATLAB", level: 80 }
  ],
  programming: [
    { name: "Python", level: 85 },
    { name: "C++", level: 80 },
    { name: "ROS", level: 75 },
    { name: "Arduino", level: 85 }
  ],
  manufacturing: [
    { name: "CNC Machining", level: 85 },
    { name: "3D Printing", level: 90 },
    { name: "Laser Cutting", level: 80 },
    { name: "Welding & Assembly", level: 75 }
  ]
};

export const experience = [
  {
    id: 1,
    title: "Senior Robotics Engineer",
    company: "Tech Robotics Inc.",
    location: "City, Country",
    period: "2022 - Present",
    description: [
      "Lead mechanical design and fabrication of autonomous robotic systems",
      "Manage system-level integration and testing protocols",
      "Collaborate with cross-functional teams for product development"
    ]
  },
  {
    id: 2,
    title: "Robotics Engineer",
    company: "Innovation Labs",
    location: "City, Country",
    period: "2019 - 2022",
    description: [
      "Designed and fabricated robotic prototypes for research projects",
      "Conducted comprehensive testing and validation procedures",
      "Optimized manufacturing processes for cost reduction"
    ]
  },
  {
    id: 3,
    title: "Junior Mechanical Engineer",
    company: "Engineering Solutions",
    location: "City, Country",
    period: "2017 - 2019",
    description: [
      "Assisted in CAD modeling and technical documentation",
      "Performed assembly and quality control testing",
      "Supported senior engineers in system integration tasks"
    ]
  }
];

export const projects = [
  {
    id: 1,
    title: "Autonomous Mobile Robot Platform",
    category: "Robotics",
    description: "Designed and fabricated a fully autonomous mobile robot platform with advanced navigation capabilities. Includes custom mechanical chassis, sensor integration, and robust assembly.",
    technologies: ["SolidWorks", "ROS", "3D Printing", "Arduino"],
    image: "https://images.unsplash.com/photo-1581092334247-44dd684e3c82?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NTYxODd8MHwxfHNlYXJjaHwyfHxyb2JvdGljcyUyMGVuZ2luZWVyaW5nfGVufDB8fHx8MTc3NTI0MDQwNnww&ixlib=rb-4.1.0&q=85",
    link: "#"
  },
  {
    id: 2,
    title: "Robotic Arm Manipulator",
    category: "Manipulation",
    description: "Developed a 6-DOF robotic arm for precision manipulation tasks. Features include custom joint design, torque optimization, and integrated control system.",
    technologies: ["CATIA", "ANSYS", "CNC Machining", "Python"],
    image: "https://images.pexels.com/photos/8439008/pexels-photo-8439008.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    link: "#"
  },
  {
    id: 3,
    title: "Automated Assembly System",
    category: "Automation",
    description: "Created an automated assembly system for manufacturing applications. Integrated vision systems, pneumatic actuators, and precision positioning mechanisms.",
    technologies: ["AutoCAD", "PLC", "Vision Systems", "Pneumatics"],
    image: "https://images.pexels.com/photos/9242858/pexels-photo-9242858.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    link: "#"
  },
  {
    id: 4,
    title: "Quadruped Walking Robot",
    category: "Robotics",
    description: "Designed mechanical structure and locomotion system for a quadruped robot. Focused on gait optimization, structural integrity, and dynamic stability.",
    technologies: ["Fusion 360", "MATLAB", "3D Printing", "C++"],
    image: "https://images.unsplash.com/photo-1581092334651-ddf26d9a09d0?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NTYxODd8MHwxfHNlYXJjaHwzfHxyb2JvdGljcyUyMGVuZ2luZWVyaW5nfGVufDB8fHx8MTc3NTI0MDQwNnww&ixlib=rb-4.1.0&q=85",
    link: "#"
  },
  {
    id: 5,
    title: "Drone Frame Design",
    category: "UAV",
    description: "Engineered lightweight yet durable drone frame using advanced composite materials. Optimized for payload capacity and flight stability.",
    technologies: ["SolidWorks", "Carbon Fiber", "FEA Analysis"],
    image: "https://images.unsplash.com/photo-1606337321936-02d1b1a4d5ef?crop=entropy&cs=srgb&fm=jpg&ixid=M3w3NDk1Nzh8MHwxfHNlYXJjaHwxfHxtZWNoYW5pY2FsJTIwZW5naW5lZXJpbmd8ZW58MHx8fHwxNzc1MjQwNDI0fDA&ixlib=rb-4.1.0&q=85",
    link: "#"
  },
  {
    id: 6,
    title: "Gripper Mechanism System",
    category: "Manipulation",
    description: "Developed adaptive gripper mechanism for handling various object geometries. Features force sensing and compliant contact surfaces.",
    technologies: ["CATIA", "3D Printing", "Force Sensors", "Arduino"],
    image: "https://images.unsplash.com/photo-1581092333203-42374bcf7d89?crop=entropy&cs=srgb&fm=jpg&ixid=M3w3NDk1Nzh8MHwxfHNlYXJjaHwyfHxtZWNoYW5pY2FsJTIwZW5naW5lZXJpbmd8ZW58MHx8fHwxNzc1MjQwNDI0fDA&ixlib=rb-4.1.0&q=85",
    link: "#"
  }
];

export const publications = [
  {
    id: 1,
    title: "Advanced Mechanical Design Strategies for Autonomous Robotic Systems",
    authors: "Your Name, Co-Author Name, Another Author",
    journal: "Journal of Robotics Engineering",
    year: "2024",
    link: "#",
    doi: "10.1234/example.doi"
  },
  {
    id: 2,
    title: "Optimization Techniques for Robotic Arm Fabrication and Assembly",
    authors: "Your Name, Collaborator Name",
    conference: "International Conference on Robotics and Automation (ICRA)",
    year: "2023",
    link: "#",
    doi: "10.1234/example.doi"
  },
  {
    id: 3,
    title: "System-Level Integration Methodologies in Modern Robotics",
    authors: "Your Name, Team Member, Research Lead",
    journal: "IEEE Transactions on Robotics",
    year: "2023",
    link: "#",
    doi: "10.1234/example.doi"
  },
  {
    id: 4,
    title: "Novel Approaches to Robotic Prototype Testing and Validation",
    authors: "Your Name, Co-Researcher",
    conference: "Robotics: Science and Systems (RSS)",
    year: "2022",
    link: "#",
    doi: "10.1234/example.doi"
  }
];

export const gallery = [
  {
    id: 1,
    title: "Robotic Assembly Process",
    image: "https://images.unsplash.com/photo-1519752594763-2633d8d4ea29?crop=entropy&cs=srgb&fm=jpg&ixid=M3w3NDk1Nzh8MHwxfHNlYXJjaHwzfHxtZWNoYW5pY2FsJTIwZW5naW5lZXJpbmd8ZW58MHx8fHwxNzc1MjQwNDI0fDA&ixlib=rb-4.1.0&q=85",
    category: "Assembly"
  },
  {
    id: 2,
    title: "Precision Manufacturing",
    image: "https://images.pexels.com/photos/633850/machine-mill-industry-steam-633850.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    category: "Manufacturing"
  },
  {
    id: 3,
    title: "CAD Design Workstation",
    image: "https://images.unsplash.com/photo-1537462715879-360eeb61a0ad?crop=entropy&cs=srgb&fm=jpg&ixid=M3w3NDk1Nzh8MHwxfHNlYXJjaHw0fHxtZWNoYW5pY2FsJTIwZW5naW5lZXJpbmd8ZW58MHx8fHwxNzc1MjQwNDI0fDA&ixlib=rb-4.1.0&q=85",
    category: "Design"
  },
  {
    id: 4,
    title: "Testing Laboratory",
    image: "https://images.pexels.com/photos/7568427/pexels-photo-7568427.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    category: "Testing"
  },
  {
    id: 5,
    title: "Fabrication Workshop",
    image: "https://images.unsplash.com/photo-1581092334247-44dd684e3c82?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NTYxODd8MHwxfHNlYXJjaHwyfHxyb2JvdGljcyUyMGVuZ2luZWVyaW5nfGVufDB8fHx8MTc3NTI0MDQwNnww&ixlib=rb-4.1.0&q=85",
    category: "Fabrication"
  },
  {
    id: 6,
    title: "System Integration",
    image: "https://images.pexels.com/photos/8439008/pexels-photo-8439008.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    category: "Integration"
  }
];

export const videos = [
  {
    id: 1,
    title: "Autonomous Robot Demo",
    description: "Demonstration of autonomous navigation and obstacle avoidance",
    thumbnail: "https://images.unsplash.com/photo-1581092334247-44dd684e3c82?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NTYxODd8MHwxfHNlYXJjaHwyfHxyb2JvdGljcyUyMGVuZ2luZWVyaW5nfGVufDB8fHx8MTc3NTI0MDQwNnww&ixlib=rb-4.1.0&q=85",
    videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ"
  },
  {
    id: 2,
    title: "Robotic Arm Operation",
    description: "Precision manipulation and pick-and-place operations",
    thumbnail: "https://images.pexels.com/photos/8439008/pexels-photo-8439008.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ"
  },
  {
    id: 3,
    title: "Assembly Process Timelapse",
    description: "Complete robot assembly from components to finished system",
    thumbnail: "https://images.pexels.com/photos/9242858/pexels-photo-9242858.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ"
  }
];

export const cadModels = [
  {
    id: 1,
    title: "Mobile Robot Chassis",
    description: "Complete 3D CAD model of autonomous mobile robot platform",
    thumbnail: "https://images.unsplash.com/photo-1606337321936-02d1b1a4d5ef?crop=entropy&cs=srgb&fm=jpg&ixid=M3w3NDk1Nzh8MHwxfHNlYXJjaHwxfHxtZWNoYW5pY2FsJTIwZW5naW5lZXJpbmd8ZW58MHx8fHwxNzc1MjQwNDI0fDA&ixlib=rb-4.1.0&q=85",
    modelUrl: "#",
    software: "SolidWorks"
  },
  {
    id: 2,
    title: "Robotic Arm Assembly",
    description: "6-DOF manipulator with detailed joint mechanisms",
    thumbnail: "https://images.unsplash.com/photo-1581092333203-42374bcf7d89?crop=entropy&cs=srgb&fm=jpg&ixid=M3w3NDk1Nzh8MHwxfHNlYXJjaHwyfHxtZWNoYW5pY2FsJTIwZW5naW5lZXJpbmd8ZW58MHx8fHwxNzc1MjQwNDI0fDA&ixlib=rb-4.1.0&q=85",
    modelUrl: "#",
    software: "CATIA"
  },
  {
    id: 3,
    title: "Gripper Mechanism",
    description: "Adaptive gripper with force sensing components",
    thumbnail: "https://images.unsplash.com/photo-1537462715879-360eeb61a0ad?crop=entropy&cs=srgb&fm=jpg&ixid=M3w3NDk1Nzh8MHwxfHNlYXJjaHw0fHxtZWNoYW5pY2FsJTIwZW5naW5lZXJpbmd8ZW58MHx8fHwxNzc1MjQwNDI0fDA&ixlib=rb-4.1.0&q=85",
    modelUrl: "#",
    software: "Fusion 360"
  },
  {
    id: 4,
    title: "Drone Frame Structure",
    description: "Lightweight composite frame with mounting points",
    thumbnail: "https://images.unsplash.com/photo-1519752594763-2633d8d4ea29?crop=entropy&cs=srgb&fm=jpg&ixid=M3w3NDk1Nzh8MHwxfHNlYXJjaHwzfHxtZWNoYW5pY2FsJTIwZW5naW5lZXJpbmd8ZW58MHx8fHwxNzc1MjQwNDI0fDA&ixlib=rb-4.1.0&q=85",
    modelUrl: "#",
    software: "SolidWorks"
  }
];
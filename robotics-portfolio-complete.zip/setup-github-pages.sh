#!/bin/bash

# GitHub Pages Setup Script
# This script helps you configure your portfolio for GitHub Pages deployment

echo "🚀 GitHub Pages Portfolio Setup"
echo "================================"
echo ""

# Get GitHub username
read -p "Enter your GitHub username: " github_username

# Get repository name
read -p "Enter your repository name (e.g., robotics-portfolio): " repo_name

# Get GitHub repository URL
read -p "Enter your GitHub repository URL (e.g., https://github.com/username/repo.git): " repo_url

echo ""
echo "📝 Configuration Summary:"
echo "  Username: $github_username"
echo "  Repository: $repo_name"
echo "  GitHub URL: $repo_url"
echo "  Your site will be: https://$github_username.github.io/$repo_name"
echo ""

read -p "Is this correct? (y/n): " confirm

if [ "$confirm" != "y" ]; then
    echo "❌ Setup cancelled. Please run the script again."
    exit 1
fi

echo ""
echo "⚙️  Configuring your portfolio..."

# Update package.json homepage field
cd /app/frontend
sed -i "s|https://YOUR_GITHUB_USERNAME.github.io/YOUR_REPO_NAME|https://$github_username.github.io/$repo_name|g" package.json

echo "✅ Updated package.json with your GitHub Pages URL"

# Initialize git
cd /app
git init
echo "✅ Initialized git repository"

# Add all files
git add .
echo "✅ Added all files to git"

# Create initial commit
git commit -m "Initial commit: Robotics portfolio website"
echo "✅ Created initial commit"

# Add remote
git remote add origin "$repo_url"
echo "✅ Added GitHub remote"

# Rename to main branch
git branch -M main
echo "✅ Renamed branch to main"

echo ""
echo "🎉 Setup Complete!"
echo ""
echo "📋 Next Steps:"
echo "  1. Push your code to GitHub:"
echo "     git push -u origin main"
echo ""
echo "  2. Deploy to GitHub Pages:"
echo "     cd /app/frontend && yarn deploy"
echo ""
echo "  3. Enable GitHub Pages in your repository settings:"
echo "     - Go to: https://github.com/$github_username/$repo_name/settings/pages"
echo "     - Set Source to: gh-pages branch"
echo ""
echo "  4. Visit your live site in 2-5 minutes:"
echo "     https://$github_username.github.io/$repo_name"
echo ""
echo "📖 For detailed instructions, see: /app/GITHUB_PAGES_DEPLOYMENT.md"
